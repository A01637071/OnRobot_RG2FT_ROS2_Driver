# OnRobot_RG2-FT_ROS2
ROS2 package for controlling and reading from OnRobot RG2-FT gripper
